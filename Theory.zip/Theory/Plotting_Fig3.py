from scipy.io import loadmat
from pylab import *
import matplotlib.colors as colors

ms=['-','--',':']



fig, ax=plt.subplots()
norm=colors.LogNorm(vmin=0.0001, vmax=0.011)

S=loadmat('data/MeasurementResults_Fig3.mat')
Renyi_av_all=S['Renyi2']
RenyiStd_av_all=S['Renyi2_std']
purities_theory=np.loadtxt('data/purity_10outof20_Decoherence.txt')
purities_theory_u=np.loadtxt('data/purity_10outof20_Unitary.txt')



for t,T in enumerate([0.0,0.001,0.002,0.003,0.004,0.006,0.01]):


        if t==6:
            ax.errorbar(list(range(6, 13)), Renyi_av_all[t, :7], RenyiStd_av_all[t, :7], fmt='o', color=cm.viridis(norm(T + 0.0001)), capthick=1.5, markersize=8, capsize=4, elinewidth=1.5, label='$' + str(int(T * 1000)) + '\,$ms')
            ax.plot(list(range(6, 16)), -np.log2(purities_theory[int(T * 1000), :]), ':', color=cm.viridis(norm(T + 0.0001)))


        elif t==5:
            ax.errorbar(list(range(6, 14)), Renyi_av_all[t, :8], RenyiStd_av_all[t, :8], fmt='o',
                        color=cm.viridis(norm(T + 0.0001)), capthick=1.5, markersize=6, capsize=4, elinewidth=1.5,
                        label=r'\hspace{0.5cm}$\phantom{1}' + str(int(T * 1000)) +'\,$ms')
            ax.plot(list(range(6, 16)), -np.log2(purities_theory[int(T * 1000), :]), ':', color=cm.viridis(norm(T + 0.0001)))



        else:
            ax.errorbar(list(range(6, 16)), Renyi_av_all[t, :], RenyiStd_av_all[t, :], fmt='o',
                        color=cm.viridis(norm(T + 0.0001)), capthick=1.5, markersize=6, capsize=4, elinewidth=1.5,
                        label='$\phantom{1}' + str(int(T * 1000)) +'\,$ms')
            ax.plot(list(range(6, 16)), -np.log2(purities_theory[int(T * 1000), :]), ':', color=cm.viridis(norm(T + 0.0001)))


x=linspace(5.8,15.2,1000)
y=[i-5 for i in x]
ax.fill_between(x, y, 10, facecolor='grey', alpha=0.75)

ax.set_xlabel('$i$')
ax.set_ylabel(r'$S^{(2)}\left(\rho_{[6\rightarrow i]}\right)$')
ax.set_xticks([7, 9, 11, 13, 15])
ax.set_xlim([5.8, 15.2])
ax.set_ylim([-0.1, 7.5])



plt.show()