from pylab import *
import pickle

from scipy.io import loadmat

import matplotlib.colors as colors


def find_nearest(array,value):
    idx = (np.abs(array-value)).argmin()
    return idx,array[idx]



dname = 'data'

samples=list(range(35))

Na = [10]
alphaa = [-1]

Deltaa =[0,-1]


deca=[0,1]

tini=0
tfinal=0.025
Tlist=np.linspace(tini,tfinal,250)

Subsystems={}
Subsystems['fwd']=[ list(range(i)) for i in range(1,11) ]


nsa,nx,ny,nz =len(samples), len(Na), len(Deltaa), len(deca)
Renyi2nd = zeros((nsa, nx, ny, nz,len(Tlist),len(Subsystems['fwd'])))


for isa in range(nsa):
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):


                sample, N, delta, dec = samples[isa], Na[ix], Deltaa[iy], deca[iz]
                
                if delta==0: sample=0
                
                alpha=-1
                
                #print(sample, N, delta, dec,alpha)

                filename='XY_{:d}_{:d}_{:.2f}_{:.2f}_{:.3f}_{:.3f}_{:d}_{:d}_{:d}_{:d}'.format(sample,N, delta, alpha,tini, tfinal,len(Tlist),dec,dec,dec)

                f=open(dname+'/'+filename, 'rb')
                S = pickle.load(f,encoding='latin1')
                Renyi2nd[isa,ix, iy, iz,:,:] = S['Renyi2nd']['fwd']

Renyi2nd=np.mean(Renyi2nd,axis=0)
ms=['-','--',':']



fig,ax=plt.subplots()
norm=colors.LogNorm(vmin=0.0001, vmax=0.02)
for i,d in enumerate(Deltaa):
    ax.plot(Tlist*1000, Renyi2nd[ 0, i, 0, :, 4], '--',color=cm.RdBu(i/(len(Deltaa)-1)),linewidth=1.5)
    ax.plot(Tlist*1000, Renyi2nd[ 0, i, 1, :, 4], '-',color=cm.RdBu(i/(len(Deltaa)-1)),linewidth=1.5)

S=loadmat('data/MeasurementResults_Fig4_Dis.mat')
Renyi_av_all=S['Renyi2_dis']
RenyiStd_av_all=S['Renyi2_std_dis']
p1=ax.errorbar(np.array([0.001,0.002,0.004,0.006,0.01,0.016,0.02])*1000, Renyi_av_all[:,4], RenyiStd_av_all[:,4], fmt='o', color=cm.RdBu(1.),
             capthick=1.5, markersize=6, capsize=4, elinewidth=1.5)


S=loadmat('data/MeasurementResults_Fig2.mat')
Renyi_av_all=S['Renyi2']
RenyiStd_av_all=S['Renyi2_std']
p2=ax.errorbar(np.array([0.0,0.001,0.002,0.003,0.004,0.005])*1000, Renyi_av_all[:,4], RenyiStd_av_all[:,4], fmt='o', color=cm.RdBu(0.),
             capthick=1.5, markersize=6, capsize=4, elinewidth=1.5)


ax.set_xlabel(r'$t[$ms$]$')
ax.set_ylabel(r'$S^{(2)}\left({\rho_{[1 \rightarrow 5]}}\right)$')


plt.show()
