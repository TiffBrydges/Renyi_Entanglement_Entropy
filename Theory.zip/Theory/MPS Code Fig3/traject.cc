//This Code was used to produce Fig 3 of our paper. It is based on the ITensor library with decoherence processes implemented as quantum jumps, see supplementary information for details.
#include "itensor/all.h"
#include "spinhalf.h"
#include "toolbox.h"
#include <iostream> 
#include <fstream>
#include <ctime>
#include <random>
#include <cstdlib>
using std::vector;
using namespace itensor;
//Real PI = 3.14;
int main(int argc, char* argv[])
{
	auto input = InputGroup(argv[1],"input");
	int r = input.getInt("r");
	int nbp = input.getInt("nbp");
	int N = input.getInt("N");
	auto gamma_sp = input.getReal("gamma_sp");
	auto gamma_x = input.getReal("gamma_x");
	auto p = input.getReal("p");
	auto ttotal = input.getReal("ttotal");
	auto tstep = input.getReal("tstep");
	auto Maxm = input.getInt("Maxm");
	auto Cutoff = input.getReal("Cutoff");
	auto imin = input.getInt("imin");
	auto imax = input.getInt("imax");

	std::mt19937 e2(r+int(1000*N));
	std::uniform_real_distribution<> dist(0, 1.);
	Args args;
	args.add("Cutoff",Cutoff);
	args.add("Maxm",Maxm);
	SpinHalf sites(N);
	InitState initState(sites);
	// STARTING FROM A NEEL STATE
	for (int i=1;i<=N/2;i++)
	{
		if (dist(e2)<p)
			initState.set(2*i-1,"Up");
		else
			initState.set(2*i-1,"Dn");
		
	}
	for (int i=1;i<=N/2;i++)
		if (dist(e2)<p)
			initState.set(2*i,"Dn");
		else
			initState.set(2*i,"Up");

	MPS psi(initState);
	psi.position(1,args);
	vector<ITensor> P,CC,C;
	int max_order = 100;
	for (int b = 1;b<=N;b++)
	{
		P.push_back(sites.op("n",b));
	}

	for (int b = 1;b<=N;b++)
	{
		C.push_back(std::sqrt(gamma_sp)*sites.op("Sm",b)); //c for spontaneous emission
		C.push_back(std::sqrt(gamma_x)*2*sites.op("Sx",b)); // c for spinflip
		CC.push_back(gamma_sp*sites.op("n",b)); //c^dag c for spontaneous emission
		CC.push_back(gamma_x*sites.op("Id",b)); //c^dag c for spinflip
	}
	auto ampo = AutoMPO(sites);
	for (int b=1;b<=N;b++)
	{
		ampo += (-Cplx_i*gamma_sp)/2.,"n",b;
	}
	// Implementation of the model with a sum of exponentially decaying interactions
	std::ifstream myfile ("Jij_model.txt");
	std::string line;
	std::istringstream lin;
	while ( getline (myfile,line) )
	{
		lin.clear();
		lin.str(line);
		Real coeff_a,coeff_b;
		lin >> coeff_a >> coeff_b;
		println("got ", coeff_a, " ",coeff_b);
		for (int i=1;i<=N-1;i++)
		{
			for (int j=i+1;j<=N;j++)
			{
				ampo += coeff_a*std::pow(coeff_b,j-i),"Sp",i,"Sm",j;
				ampo += coeff_a*std::pow(coeff_b,j-i),"Sm",i,"Sp",j;
			}
		}
	}
	auto H = MPO(ampo);
	//println(maxM(H));
	auto expH = toExpH<ITensor>(ampo,tstep*Cplx_i);
	println(maxM(expH));
	Real t1 = ttotal/(nbp-1.);
	auto nt = int(t1/tstep+(1e-9*(t1/tstep)));
	if(fabs(nt*tstep-t1) > 1E-9)
	{
		Error("Timestep not commensurate with total time");
	}
	std::ofstream out(argv[2]);
	savelocals(psi,P,out,args);
	vector<Real> rnum(2*N);
	std::ofstream outd(argv[3]);
	export_dm(psi,sites,imin,imax,outd,args); // EXPORT DENSITY MATRIX
	for (int l=1;l<nbp;l++)
	{	
		for(int step = 1; step <= nt; ++step)
		{
			for (int k=1;k<=N*2;k++)
				rnum[k-1] = dist(e2);
			Jump(psi,CC,C,rnum,tstep,2,args); //ROUTINE FOR PROBABILISTIC QUANTUM JUMOS
			if (step==1)
				exactApplyMPO(psi,expH,psi,args); // TIME EVOLUTION USING ITENSOR MPO ROUTINES
			else
				fitApplyMPO(psi,expH,psi,args);
	
			psi.position(1,args);
			psi.normalize();
			if ((step*100)/nt % 10 ==0)
				println((step*100)/nt," % done " );
		}
		savelocals(psi,P,out,args); 
		export_dm(psi,sites,imin,imax,outd,args);
	}
	out.close();
	return 0;
}
