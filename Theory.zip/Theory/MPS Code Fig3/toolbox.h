//##include "global.
//##include "sites/spinhalf.h"
//#include "mps.h"
#include "itensor/all.h"
#include <iostream> 
#include <fstream>
#include <cmath> 

using std::vector;
using namespace itensor;
Real PI = 3.141592653589793;
Real Entrop(const Spectrum& spec)
{
	Real S = 0;
	for(int n = 1; n <= spec.numEigsKept(); ++n)
	{
		S += -spec.eig(n)*log(spec.eig(n))/log(2);
	}
	return S;
}
ITensor exp(ITensor x, const ITensor& I, const int max_order)
{
	ITensor expH = x/max_order + I;
	x.mapprime(1,2);
	x.mapprime(0,1);
	for(int ord = max_order-1; ord >= 1; --ord)
	{
		expH = expH*(x/ord);	
		expH.mapprime(2,1);
		expH += I;
	}
	return expH;
}
Real expect(const ITensor& A, ITensor P)
{
	Real a = real((dag(prime(A,Site))*P*A).cplx());
	return a;
}
Real purity(const ITensor& A)
{       
	auto rho = dag(prime(A,Site))*A;
	auto rhop = prime(A,Site)*dag(A);
	Real a = real((rho*rhop).cplx());
	return a;
}
Complex expectc(const ITensor& A, ITensor P)
{
	Complex a = (dag(prime(A,Site))*P*A).cplx();
	return a;
}
Complex corr(MPS psi, int i, int j, ITensor op_i,  ITensor op_j)
{
	//index linking i to i+1:
	auto ir = commonIndex(psi.A(i),psi.A(i+1),Link);
	auto C = psi.A(i)*op_i*dag(prime(prime(psi.A(i),Site),ir));
	for(int k = i+1; k < j; ++k)
	{
		C *= psi.A(k);
		C *= dag(prime(psi.A(k),Link));
	}
	C *= psi.A(j);
	C *= op_j;
	//index linking j to j-1:
	auto jl = commonIndex(psi.A(j),psi.A(j-1),Link);
	C *= dag(prime(prime(psi.A(j),Site),jl));
	return C.cplx();
}
ITensor makeKroneckerDelta(const Index& i, int plev)
{
	return delta(i,prime(i,plev));
}
void savelocals(const IQMPS& psi, const vector<IQTensor>& P, std::ofstream& out, const Args& args)
{
	auto N = P.size();
	auto psi2 = 1.*psi;
	for (int b=0;b<N;b++)
		{
			psi2.position(b+1,args);
			out <<  "\t" << expect(psi2.A(b+1),P[b]);
		}
	out << std::endl;
}
void savelocals(const MPS& psi, const vector<ITensor>& P, std::ofstream& out, const Args& args)
{
	auto N = P.size();
	auto psi2 = 1.*psi;
	for (int b=0;b<N;b++)
		{
			psi2.position(b+1,args);
			out <<  "\t" << expect(psi2.A(b+1),P[b]);
		}
	out << std::endl;
}

//void export_dm(const MPS& psi, int imin, int imax, std::string& outd, const Args& args)
//		{
//		auto psi2 = 1.*psi;
//		psi2.position(imin);
//		auto rho = psi2.A(imin)*dag(prime(psi2.A(imin),Site));
//		for (int i=imin+1;i<=imax;i++)
//		{
//			rho *= psi2.A(i)*dag(prime(psi2.A(i),Site));
//		}
//		writeToFile(outd,rho);
//		}
std::string DecToBin(int number)
{
	if ( number == 0 ) return "0";
	if ( number == 1 ) return "1";

	if ( number % 2 == 0 )
		return DecToBin(number / 2) + "0";
	else
		return DecToBin(number / 2) + "1";
}

std::string DecToBin_f(int number,int N)
{
	auto s = DecToBin(number);
	std::string  sf;
	for (int i=1;i<=N;i++)
		sf = sf +"0";
	for (int r=0;r<s.length();r++)
		sf[N-s.length()+r] = s[r];
	return sf;

}
void export_dm(MPS& psi, SpinHalf& sites, int imin, int imax, std::ofstream& outd, const Args& args) // VERSION ``MEMORY FRIENDLY" ONLY WORKS FOR 10 QUBITS
{
	int NA = imax-imin+1;
	psi.position(imin,args);
	println("start export");
	vector<IQIndexVal> vp(NA);
	vector<ITensor> psik(NA);
	
	for (int k=0;k<std::pow(2,NA);k++)
	{
		auto sk = DecToBin_f(k,NA);
		int Nk = 0;
		for (int i=0;i<NA;i++)
		{
			Nk += sk[i]-'0';
			if (sk[i]=='0')
				psik[i] = setElt(sites(imin+i)(1));
			else
				psik[i] = setElt(sites(imin+i)(2));
		}

		auto ir = commonIndex(psi.A(imin),psi.A(imin+1),Link);
		auto C = psi.A(imin)*psik[0];
		auto L = C*prime(prime(dag(psi.A(imin)),Site),ir);
		for (int i=imin+1;i<=imin+NA/2;i++)
		{
			//println("building dm ",i);
			C = psi.A(i)*psik[i-imin];
			L *= C;
			L *= dag(prime(psi.A(i)));

		}
		auto il = commonIndex(psi.A(imax-1),psi.A(imax),Link);
		C = psi.A(imax)*psik[imax-imin];
		auto R = C*prime(prime(dag(psi.A(imax)),Site),il);
		for (int i=imax-1;i>=imin+NA/2+1;i--)
		{
			//println("building dm ",i);
			C = psi.A(i)*psik[i-imin];
			R *= C;
			R *= dag(prime(psi.A(i)));

		}
		//println("R L built");
		R = R*L;
		//println("dm built");

		for (int kp=k;kp<std::pow(2,NA);kp++)
		{
			Real rhor,rhoi;
			auto skp = DecToBin_f(kp,NA);
			int Nkp = 0;
			for (int i=0;i<NA;i++)
				Nkp += skp[i]-'0';
			if (Nk==Nkp)
			{
				for (int i=0;i<NA;i++)
				{
					if (skp[i]=='0')
						vp[i] = prime(sites(imin+i))(1);
					else				
						vp[i] = prime(sites(imin+i))(2);
				}

				auto rhoc = R.cplx(vp[0],vp[1],vp[2],vp[3],vp[4],vp[5],vp[6],vp[7],vp[8],vp[9]);
				rhor = real(rhoc);
				rhoi = imag(rhoc);
			}
			else
			{
				rhor =  0;
				rhoi = 0;
			}
			outd << rhor << "\t" << rhoi << std::endl;;
		}
	}
	println("end export");
}
void Jump(MPS& psi, const vector<ITensor>& CC, const vector<ITensor>& C, const vector<Real>& rnum, Real tstep, int  nop, const Args& args)
{
	auto N = psi.N();
	for (int i=1;i<= N;i++)
	{
		psi.position(i,args);
		for (int n=0;n<nop;n++)
		{
			Real probaJump = expect(psi.A(i),CC[nop*(i-1)+n])*tstep;
			if (rnum[nop*(i-1)+n]<probaJump)
			{
				println("jump", "site ",i," op ", n);
				psi.Aref(i) = noprime(C[nop*(i-1)+n]*psi.A(i));
				psi.normalize();
			}
		}

	}
	psi.position(1,args);
}
MPS toMPS(IQMPS const& psi)
{
	int N = psi.N();
	MPS res;
	if(psi.sites()) res = MPS(psi.sites());
	else            res = MPS(N);
	for(int j = 0; j <= N+1; ++j)
	{
		res.Aref(j) = ITensor(psi.A(j));
	}
	res.leftLim(psi.leftLim());
	res.rightLim(psi.rightLim());
	return res;
}
