from pylab import *
import pickle

from scipy.io import loadmat

import matplotlib.colors as colors


def find_nearest(array,value):
    idx = (np.abs(array-value)).argmin()
    return idx,array[idx]



dname = 'data'

samples=list(range(35))

Na = [10]
alphaa = [-1]

Deltaa =[-1]


deca=[0,1]

tini=0
tfinal=0.025
Tlist=np.linspace(tini,tfinal,250)

Subsystems={}
Subsystems['36']=  [[2,3,4],[5,6,7],[2,3,4,5,6,7],[1,2,3],[6,7,8],[1,2,3,6,7,8],[0,1,2],[7,8,9],[0,1,2,7,8,9] ]


nsa,nx,ny,nz =len(samples), len(Na), len(Deltaa), len(deca)
Renyi2nd_36 = zeros((nsa, nx, ny, nz,len(Tlist),len(Subsystems['36'])))


for isa in range(nsa):
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):


                sample, N, delta, dec = samples[isa], Na[ix], Deltaa[iy], deca[iz]
                
                if delta==0: sample=0
                
                alpha=-1
                
                #print(sample, N, delta, dec,alpha)

                filename='XY_{:d}_{:d}_{:.2f}_{:.2f}_{:.3f}_{:.3f}_{:d}_{:d}_{:d}_{:d}'.format(sample,N, delta, alpha,tini, tfinal,len(Tlist),dec,dec,dec)

                f=open(dname+'/'+filename, 'rb')
                S = pickle.load(f,encoding='latin1')
                Renyi2nd_36[isa, ix, iy, iz,:,:] = S['Renyi2nd']['36']


Renyi2nd_36=np.mean(Renyi2nd_36,axis=0)


fig,ax=plt.subplots()
norm=colors.LogNorm(vmin=0.0001, vmax=0.02)
ls=['--','-']
for id,d in enumerate(deca):


    for i in range(len(Subsystems['36']) // 3):
        mut=Renyi2nd_36[0, 0, id, :, 3 * i] + Renyi2nd_36[0, 0, id, :, 3 * i + 1] - Renyi2nd_36[0, 0, id, :,
                                                                                      3 * i + 2]
        ax.plot(Tlist * 1000, mut,ls[id], color=cm.Blues((i + 2) / (len(Subsystems['36']) // 3 + 1)),
                  linewidth=1.5)


S=loadmat('data/MeasurementsResults_Fig4b_mut_36.mat')
mutual_info=S['mutual_info']
mutual_info_err=S['mutual_info_err']
legendlabs=['$[345]\!:\![678]$','$[234]\!:\![789]$','$[123]\!:\![891\!0]$']


for i in range(len(Subsystems['36'])//3):
    ax.errorbar(np.array([0.001,0.002,0.004,0.006,0.01,0.016,0.02])*1000, mutual_info[:,i], mutual_info_err[:,i], fmt='o', color=cm.Blues((i+2)/(len(Subsystems['36'])//3+1)),
             capthick=1.5, markersize=6, capsize=4, elinewidth=1.5,label=legendlabs[i])

ax.legend(fontsize=13,ncol=3,columnspacing=0.,handletextpad=0.,mode='expand')
ax.set_ylim([-0.2,2.25])
ax.set_xlabel(r'$t[$ms$]$')
ax.set_ylabel(r'$I^{(2)}(\rho_A : \rho_B)$')



plt.show()
