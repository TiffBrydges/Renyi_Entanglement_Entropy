from pylab import *
import pickle
from scipy.io import loadmat

import matplotlib.transforms as mtransforms
import matplotlib.colors as colors



dname = 'data'

samples=list(range(1))
Na = [10]
alphaa = [-1]
deca=[0,1]
Deltaa =[0]


tini=0
tfinal=0.025
Tlist=np.linspace(tini,tfinal,num=250)


Subsystems={}
Subsystems['fwd']=[ list(range(i)) for i in range(1,11) ]


nsa,nx,ny,nz =len(samples), len(Na), len(Deltaa), len(deca)
Renyi2nd = zeros((nsa, nx, ny, nz,len(Tlist),len(Subsystems['fwd'])))

for isa in range(nsa):
    for ix in range(nx):
        for iy in range(ny):
            for iz in range(nz):
                
                sample, N, delta, dec = samples[isa], Na[ix], Deltaa[iy], deca[iz]
                
                alpha=-1
                
                print(sample, N, delta, dec,alpha)
                
                filename='XY_{:d}_{:d}_{:.2f}_{:.2f}_{:.3f}_{:.3f}_{:d}_{:d}_{:d}_{:d}'.format(sample,N, delta, alpha,tini, tfinal,len(Tlist),dec,dec,dec)
                f=open(dname+'/'+filename, 'rb')
                S = pickle.load(f,encoding='latin1')
                Renyi2nd[isa,ix, iy, iz,:,:] = S['Renyi2nd']['fwd']


purity=np.mean(np.power(2*np.ones(shape((Renyi2nd))),-Renyi2nd),axis=0)
Renyi2nd=np.mean(Renyi2nd,axis=0)

def find_nearest(array,value):
    idx = (np.abs(np.array(array)-value)).argmin()
    return idx,array[idx]

S=loadmat('data/MeasurementResults_Fig2.mat')
Renyi_av_all=S['Renyi2']
RenyiStd_av_all=S['Renyi2_std']
PurityConnected_av_all=S['TrRho2']
PurityStdConnected_av_all=S['TrRho2_std']



fig,ax=plt.subplots()
norm=colors.LogNorm(vmin=0.0001, vmax=0.011)
for t,T in enumerate([0,0.001,0.002,0.003,0.004,0.005]):
    
    idx,value =find_nearest(Tlist,T)
    #ax.plot(list(range(1,11)), Renyi2nd[ 0, 0, 0, idx, :], '--',color=cm.viridis(norm(T+0.0001)),linewidth=1.5)
    ax.plot(list(range(1,11)), Renyi2nd[ 0, 0, 1, idx, :], ':',color=cm.viridis(norm(T+0.0001)),linewidth=1.5)
    ax.errorbar(list(range(1, 11)), Renyi_av_all[t, :], RenyiStd_av_all[t, :], fmt='o',
                 color=cm.viridis(norm(T + 0.0001)), capthick=1.5, markersize=8, capsize=4, elinewidth=1.5,
                 label='$' + str(int(T * 1000)) + '$')

ax.set_xlabel('$i$')
ax.set_ylabel(r'$S^{(2)}\left(\rho_{[1\rightarrow i]}\right)$')
ax.set_xticks([2,4,6,8,10])
ax.set_yticks([0,1,2,3])
ax.set_xlim([0.8,10.2])
ax.set_ylim([-0.1,3.])

x=linspace(0.8,11,1000)
y=[i for i in x]
trans = mtransforms.blended_transform_factory(ax.transData, ax.transAxes)
ax.fill_between(x, y, 10,
                facecolor='grey', alpha=0.75)



fig,ax=plt.subplots()
norm=colors.LogNorm(vmin=0.0001, vmax=0.011)
for t, T in enumerate([0, 0.001, 0.002, 0.003, 0.004, 0.005]):
    idx, value=find_nearest(Tlist, T)
    # ax.plot(list(range(1,11)), Renyi2nd[ 0, 0, 0, idx, :], '--',color=cm.viridis(norm(T+0.0001)),linewidth=1.5)
    ax.plot(list(range(1, 11)), purity[0, 0, 1, idx, :], ':', color=cm.viridis(norm(T + 0.0001)), linewidth=1.5)
    ax.errorbar(list(range(1, 11)), PurityConnected_av_all[t, :], PurityStdConnected_av_all[t, :], fmt='o',
                color=cm.viridis(norm(T + 0.0001)), capthick=1.5, markersize=8, capsize=4, elinewidth=1.5,
                label='$' + str(int(T * 1000)) + '$')

x=linspace(0.8,11,1000)
y=[1/2**i for i in x]
trans = mtransforms.blended_transform_factory(ax.transData, ax.transAxes)
ax.fill_between(x, 0, y,
                facecolor='grey', alpha=0.75, transform=trans)


ax.set_xlabel('$i$')
ax.set_ylabel(r'Tr$\left(\rho^2_{[1\rightarrow i]}\right)$')
ax.set_xticks([2,4,6,8,10])
ax.set_xlim([0.8,10.2])
ax.set_ylim([0,1.05])


plt.show()
