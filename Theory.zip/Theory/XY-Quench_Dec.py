# To execute this, one needs python 3, numpy, scipy and qutip

import numpy as np
import pickle
import itertools as it
from qutip import *
import os
from scipy.io import loadmat
import sys



# get the individual terms to construct the Hamiltonian
def get_H_XY(N):
    I=tensor([qeye(2)] * N)
    c=list(it.combinations(range(N), 2))
    HD, HPM=[0 * I for x in range(N)], [0 * I for x in c]
    for i in range(N):
        l=[qeye(2)] * N
        l[i]=sigmaz()
        HD[i]=tensor(l).data.todense()
    for s in range(len(c)):
        i, j=c[s]
        l=[qeye(2)] * N
        l[i]=sigmap()
        l[j]=sigmam()
        HPM[s]=tensor(l).data.todense()
        HPM[s]+=np.conjugate(np.transpose(HPM[s]))
    return HD, HPM

# to model the depolarizing noise during the application of the random unitaries
def get_Uk_depolarizing(N,pLim):

    uk = [np.sqrt(1-3./2*pLim)*qeye(2)]+[np.sqrt(pLim/2.)*s for s in [sigmax(),sigmay(),sigmaz()] ]

    U = [ [] for i in range(N) ]
    Nk = len(uk)
    for i in range(N):
        U[i] = [ [] for k in range(Nk) ]
        l = [qeye(2)]*N
        for k in range(Nk):
            l[i] = uk[k]
            U[i][k] = tensor(l)
    return U



def doit(params):


    sample, N, Delta, alpha, dec_ini, dec_evo, dec_final, r = params


    print(params)
    sys.stdout.flush()

    # Initial State

    if dec_ini == 1:

        if Delta == 0:
            S=loadmat('data/InitialState_20180222.mat')
            probup=S['avpDI'][0]
        elif Delta == -1:
            S=loadmat('data/InitialState_20180330.mat')
            probup=S['avpDI'][0]
        else:
            print('No initial state data available')
            probup=[i % 2 for i in range(N)]

        rho=[]
        for i in range(N):

            rho.append(probup[i] * fock_dm(2, 0) + (1. - probup[i]) * fock_dm(2, 1))
        rho=tensor(rho)

    else:

        probup=[i % 2 for i in range(N)]
        rho=[]
        for i in range(N):
            rho.append(probup[i] * fock(2, 0) + (1. - probup[i]) * fock(2, 1))
        rho=tensor(rho)

    
    # Construct Hamiltonian


    HD, HPM = get_H_XY(N)


    S=loadmat('data/Jij_' + str(N) + '.mat')
    Jij=S['Jij']
    Jijmax=np.amax(np.abs(Jij))
    print(Jijmax)

    if Delta==-1:
        disordera=np.load('data/Disorder_35_Experiment_Delta_3.npy')
        disorder=disordera[sample,:]
    else:
        disorder=[np.random.uniform(-Delta,Delta)*Jijmax for i in range(N)]

    print(disorder)

    H = sum([disorder[i]  * h for i,h in enumerate(HD)], 0)
    c = list(it.combinations(range(N), 2))
    x = np.array(range(N))
    y = np.zeros(N)


    if alpha != -1 :

        Jij=np.zeros((N, N))
        for i in range(N):
            for j in range(N):
                if i != j: Jij[i, j]=Jijmax / ((x[i] - x[j]) ** 2 + (y[i] - y[j]) ** 2) ** (alpha/2.)

    for s, cs in enumerate(c):
        i, j = cs
        H+=HPM[s]*(Jij[i,j]+Jij[j,i])

    print(sample,'Hamiltonian constructed')
    sys.stdout.flush()

    # Do the time evolution



    opts=Options(num_cpus=1,openmp_threads=1,use_openmp=False)


    if dec_evo==1:
        
        # Spontaneous decay and spinflips during the evolution
        gamma_decay=gamma_decaya[0]
        gamma_spinflip=gamma_spinflipa[0]

        H=Qobj(H, dims=[[2] * N, [2] * N])

        C_spinflip=[0 for i in range(N)]
        C_decay=[0 for i in range(N)]
        for i in range(N):
            l=[qeye(2)] * N
            l[i]=np.sqrt(gamma_spinflip) * sigmax()
            C_spinflip[i]=tensor(l)
            l[i]=np.sqrt(gamma_decay) * sigmam()
            C_decay[i]=tensor(l)
        C=C_spinflip + C_decay
        R = mesolve(H,rho,Tlist,C,[],options=opts).states

    else:
        
        # Unitary evolution

        gamma_decay=0.
        gamma_spinflip=0.

        H=Qobj(H, dims=[[2] * N, [2] * N])

        if not isket(rho):
            R=mesolve(H, rho, Tlist, [], [],options=opts).states
        else:
            R=sesolve(H, rho, Tlist,[],options=opts).states
            R=[ket2dm(rhot) for rhot in R]

    print(sample,'Evolution_Done')
    sys.stdout.flush()

    if dec_final==1:
        
        # Depolarizing noise during the application of the random unitaries

        gamma_meas=gamma_measa[0]
        Uk=get_Uk_depolarizing(N,gamma_meas)
        Nk=len(Uk[0])

        for t,rhot in enumerate(R):
            for i in range(N):
                rhot=sum([Uk[i][k]*rhot*Uk[i][k].dag() for k in range(Nk)], 0)
            R[t]=rhot

    else:
        
        # Ideal measurement process
        
        gamma_meas=0.

    print(sample,'Measurement_Done')
    sys.stdout.flush()


    # R[t] contains now a list of states for the times t in Tlist
    # now the purities of the subsystems (specified in Subsystems) are calculated

    Renyi2nd={}
    Renyi2nd['fwd']=np.zeros((len(Tlist),len(Subsystems['fwd'])))
    Renyi2nd['36']=np.zeros((len(Tlist),len(Subsystems['36'])))
    spin_z_exp=1j * np.zeros((len(Tlist), N))

    for t, T in enumerate(Tlist):

        if t%50==0:
            print(sample, t)
            sys.stdout.flush()

        rho_t=R[t]

        # sanity check
        if not(rho_t.isherm):
            print(sample,t,rho_t.tr(),(rho_t*rho_t).tr())
            sys.stdout.flush()

        for j,s in enumerate(Subsystems['fwd']):
                rhoA=ptrace(rho_t,s)
                Renyi2nd['fwd'][t,j]=-np.log2((rhoA*rhoA).tr())


        for j,s in enumerate(Subsystems['36']):
                rhoA=ptrace(rho_t,s)
                Renyi2nd['36'][t,j]=-np.log2((rhoA*rhoA).tr())


        # Local magnetization
        for i, h in enumerate(HD):

            spin_z_exp[t, i]=expect(Qobj(h,dims=[[2]*N,[2]*N]),rho_t)



    filename = 'XY_{:d}_{:d}_{:.2f}_{:.2f}_{:.3f}_{:.3f}_{:d}_{:d}_{:d}_{:d}'.format(sample,N, Delta, alpha,tini, tfinal,len(Tlist),dec_ini,dec_evo,dec_final)


    S={}
    S['Tlist']=Tlist
    S['Renyi2nd']=Renyi2nd
    S['spin_z_exp'] = spin_z_exp
    S['Subsystems'] = Subsystems
    S['disorder'] = disorder
    S['Jij']=Jij
    S['Dec']=[gamma_spinflip,gamma_decay,gamma_meas]


    with open(dname + '/' + filename, 'wb') as f:
            pickle.dump(S, f)

    return Tlist,Renyi2nd,spin_z_exp


Na = [10]
alphaa = [-1]


gamma_spinflipa = [0.7]
gamma_decaya = [1./1.5]
gamma_measa = [0.0095]

Subsystems={}
Subsystems['fwd']=[ list(range(i)) for i in range(1,11) ]
Subsystems['36']=  [[2,3,4],[5,6,7],[2,3,4,5,6,7],[1,2,3],[6,7,8],[1,2,3,6,7,8],[0,1,2],[7,8,9],[0,1,2,7,8,9] ]


dname = 'data'

#Clean system
samples=list(range(1))
Deltaa =[0 ]

#Disordered system
#samples=list(range(35))
#Deltaa =[-1 ]

# to include all decoherence sources put all to 1
dec_inia=[0]
dec_evoa=[0]
dec_finala=[0]

tini=0
tfinal=0.025
Tlist=np.linspace(tini,tfinal,num=250)

# To calculate only the specific times shown in Fig 1 uncomment:
#def find_nearest(array,value):
#    idx = (np.abs(array-value)).argmin()
#    return idx,array[idx]
#Tlist=[find_nearest(Tlist,T)[1] for T in [0.,0.001,0.002,0.003,0.004,0.005]]
#tfinal=Tlist[-1]
#print(Tlist)

if not os.path.exists(dname):
    os.makedirs(dname)

params = list( it.product(samples,Na, Deltaa, alphaa , dec_inia, dec_evoa, dec_finala))
params = [list(params[i]) + [i] for i in range(len(params))]
S = serial_map(doit,params)
